/**
 * TDD Module - Issue #10
 * Exportaciones de Test-Driven Development
 */

export { 
  TDDExecutor, 
  JestTestRunner, 
  TestRunner, 
  TestRunResult 
} from './tdd-executor';
