/**
 * Hivemind Module - Issue #26
 * Exportaciones del sistema de memoria semántica
 */

export { Hivemind } from './hivemind';
export { 
  OllamaEmbeddingBackend, 
  OpenAIEmbeddingBackend, 
  FullTextSearchBackend,
  createEmbeddingBackend,
  cosineSimilarity 
} from './embedding-backends';
