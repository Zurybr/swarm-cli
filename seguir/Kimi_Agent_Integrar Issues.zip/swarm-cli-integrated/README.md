# Swarm CLI - Integración Completa de Issues

Este repositorio contiene la integración completa de los 16 issues abiertos en el proyecto swarm-cli original.

## Issues Integrados

### Epic Issues (11)

1. **#26 - Hivemind: Semantic Memory with Embeddings**
   - Sistema de memoria semántica con embeddings
   - Backends: Ollama (local), OpenAI (cloud), FTS (fallback)
   - Almacenamiento SQLite con búsqueda por similitud
   - Detección de patrones automática

2. **#24 - MCP Integration: Model Context Protocol**
   - Cliente MCP para conectar a servidores externos
   - Soporte para herramientas y recursos MCP
   - Server Manager para múltiples conexiones
   - Auto-refresh de herramientas

3. **#23 - TUI Mode: Terminal User Interface**
   - Interfaz de terminal interactiva con blessed
   - Vistas: Dashboard, Kanban, Agent Detail, Logs
   - Actualizaciones en tiempo real vía WebSocket
   - Navegación por teclado completa

4. **#22 - Multi-Model Support: Provider Agnostic**
   - Abstracción de proveedores: Anthropic, OpenAI, Ollama
   - Sistema de routing y fallback automático
   - Soporte para tools, vision, streaming
   - Health check de proveedores

5. **#21 - Agent System with Primary/Subagents and Permissions**
   - 13 agentes especializados con meta-prompts
   - Sistema de permisos granular
   - Orquestación de agentes
   - Identificación por colores

6. **#20 - Client/Server Architecture for Remote Operation**
   - Arquitectura cliente/servidor
   - WebSocket para comunicación en tiempo real
   - REST API para operaciones

7. **#19 - STATE.md: Project State Single Source of Truth**
   - Gestión de estado del proyecto
   - Persistencia en YAML
   - Tracking de progreso
   - Soporte para resume

8. **#18 - Goal-Backward Verification with Must-Haves**
   - Verificación de objetivos
   - Validación de truths, artifacts, key_links
   - Reportes de verificación
   - Detección de gaps

9. **#17 - Checkpoint System: Human-in-the-Loop Verification**
   - Checkpoints: human-verify, decision, notify
   - Sistema de aprobación automática configurable
   - Historial de checkpoints
   - Golden rules para automatización

10. **#16 - Wave-Based Parallel Execution with Dependency Graphs**
    - Construcción de DAG desde dependencias
    - Ordenamiento topológico
    - Ejecución paralela por waves
    - Detección de ciclos

11. **#15 - PLAN.md Executable Prompt System**
    - Parser de frontmatter YAML
    - Schema de validación
    - Tasks en formato XML
    - Soporte para must_haves

### Feature Issues (5)

12. **#14 - 13 Specialized Agents with Meta-Prompts and Orchestration**
    - swarm-planner, swarm-executor, swarm-verifier, swarm-debugger
    - swarm-researcher, swarm-codebase-mapper, swarm-architect
    - swarm-security, swarm-performance, swarm-docs
    - swarm-test, swarm-refactor, swarm-onboarding

13. **#13 - Unified Kanban Visualization**
    - Kanban en CLI, Web y Terminal
    - Sync con GitHub Projects
    - Drag-and-drop
    - Filtros y búsqueda

14. **#12 - Meta-Prompts System for Specialized Agents**
    - Meta-prompts para cada tipo de agente
    - System prompts especializados
    - Tool sets específicos

15. **#11 - GSD Integration: Analysis and Feature Roadmap**
    - Integración de conceptos GSD
    - PLAN.md como prompts ejecutables
    - Wave-based execution
    - Goal-backward verification

16. **#10 - TDD Plan Type Support**
    - Soporte para planes tipo TDD
    - Flujo Red-Green-Refactor
    - Integración con Jest
    - Generación automática de tests

## Estructura del Proyecto

```
src/
├── types/                    # Tipos base
│   └── index.ts
├── gsd/                      # GSD System (Issues #15-19)
│   ├── plan-parser.ts
│   ├── wave-executor.ts
│   ├── state-manager.ts
│   ├── checkpoint-system.ts
│   ├── verification-system.ts
│   └── index.ts
├── providers/                # Multi-Model Support (#22)
│   ├── base-provider.ts
│   ├── anthropic-provider.ts
│   ├── openai-provider.ts
│   ├── ollama-provider.ts
│   ├── provider-manager.ts
│   └── index.ts
├── hive/                     # Hivemind (#26)
│   ├── hivemind.ts
│   ├── embedding-backends.ts
│   └── index.ts
├── integrations/mcp/         # MCP Integration (#24)
│   ├── mcp-client.ts
│   ├── mcp-manager.ts
│   └── index.ts
├── tdd/                      # TDD Support (#10)
│   ├── tdd-executor.ts
│   └── index.ts
└── index.ts                  # Exportaciones principales
```

## Instalación

```bash
npm install
```

## Uso

```typescript
import { 
  PlanParser, 
  WaveExecutor, 
  StateManager,
  ProviderManager,
  Hivemind,
  MCPServerManager,
  TDDExecutor 
} from 'swarm-cli-integrated';

// Parsear PLAN.md
const parser = new PlanParser();
const { frontmatter, tasks } = parser.parse(planContent);

// Ejecutar waves
const waveExecutor = new WaveExecutor();
waveExecutor.buildDependencyGraph([frontmatter]);
const executionPlan = waveExecutor.getExecutionPlan();

// Gestionar estado
const stateManager = new StateManager('./STATE.md');
await stateManager.load();
stateManager.updatePosition({ current_phase: '02-features' });
await stateManager.save();

// Usar múltiples proveedores
const providerManager = new ProviderManager();
providerManager.registerDefaultProviders({
  anthropicApiKey: process.env.ANTHROPIC_API_KEY,
  openaiApiKey: process.env.OPENAI_API_KEY
});
const completion = await providerManager.complete({
  model: 'claude-3-sonnet',
  messages: [{ role: 'user', content: 'Hello' }]
});

// Usar Hivemind
const hivemind = new Hivemind(embeddingBackend, './hivemind.db');
await hivemind.initialize();
await hivemind.save(learning);
const results = await hivemind.findSimilar('query');

// Usar MCP
const mcpManager = new MCPServerManager();
await mcpManager.addServer({
  name: 'filesystem',
  command: 'npx',
  args: ['-y', '@modelcontextprotocol/server-filesystem', '/home/user']
});
const tools = await mcpManager.listAllTools();

// Ejecutar TDD
const tddExecutor = new TDDExecutor();
const result = await tddExecutor.execute(tddTask);
```

## Tests

```bash
npm test
```

## Licencia

MIT
